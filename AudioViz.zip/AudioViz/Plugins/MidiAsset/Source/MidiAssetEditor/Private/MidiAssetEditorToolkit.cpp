// Copyright 1998-2015 Epic Games, Inc. All Rights Reserved.

#include "MidiAssetEditorPrivatePCH.h"
#include "Factories.h"
#include "SDockTab.h"


#define LOCTEXT_NAMESPACE "FMidiAssetEditorToolkit"

DEFINE_LOG_CATEGORY_STATIC(LogMidiAssetEditor, Log, All);


/* Local constants
 *****************************************************************************/

static const FName MidiAssetEditorAppIdentifier("MidiAssetEditorApp");
static const FName MidiEditorTabId("MidiEditor");


/* FMidiAssetEditorToolkit structors
 *****************************************************************************/

FMidiAssetEditorToolkit::FMidiAssetEditorToolkit(const TSharedRef<ISlateStyle>& InStyle)
	: MidiAsset(nullptr)
	, Style(InStyle)
{ }


FMidiAssetEditorToolkit::~FMidiAssetEditorToolkit()
{
	FReimportManager::Instance()->OnPreReimport().RemoveAll(this);
	FReimportManager::Instance()->OnPostReimport().RemoveAll(this);

	GEditor->UnregisterForUndo(this);
}


/* FMidiAssetEditorToolkit interface
 *****************************************************************************/

void FMidiAssetEditorToolkit::Initialize(UMidiAsset* InMidiAsset, const EToolkitMode::Type InMode, const TSharedPtr<class IToolkitHost>& InToolkitHost)
{
	MidiAsset = InMidiAsset;

	// Support undo/redo
	MidiAsset->SetFlags(RF_Transactional);
	GEditor->RegisterForUndo(this);

	// create tab layout
	const TSharedRef<FTabManager::FLayout> Layout = FTabManager::NewLayout("Standalone_MidiAssetEditor")
		->AddArea
		(
			FTabManager::NewPrimaryArea()
				->SetOrientation(Orient_Horizontal)
				->Split
				(
					FTabManager::NewSplitter()
						->SetOrientation(Orient_Vertical)
						->SetSizeCoefficient(0.66f)
						->Split
						(
							FTabManager::NewStack()
								->AddTab(GetToolbarTabId(), ETabState::OpenedTab)
								->SetHideTabWell(true)
								->SetSizeCoefficient(0.1f)
								
						)
						->Split
						(
							FTabManager::NewStack()
								->AddTab(MidiEditorTabId, ETabState::OpenedTab)
								->SetHideTabWell(true)
								->SetSizeCoefficient(0.9f)
						)
				)
		);

	FAssetEditorToolkit::InitAssetEditor(
		InMode,
		InToolkitHost,
		MidiAssetEditorAppIdentifier,
		Layout,
		true /*bCreateDefaultStandaloneMenu*/,
		true /*bCreateDefaultToolbar*/,
		InMidiAsset);

	RegenerateMenusAndToolbars();
}


/* FAssetEditorToolkit interface
 *****************************************************************************/

FString FMidiAssetEditorToolkit::GetDocumentationLink() const
{
	return FString(TEXT("https://github.com/ue4plugins/MidiAsset"));
}


void FMidiAssetEditorToolkit::RegisterTabSpawners(const TSharedRef<class FTabManager>& TabManager)
{
	WorkspaceMenuCategory = TabManager->AddLocalWorkspaceMenuCategory(LOCTEXT("WorkspaceMenu_MidiAssetEditor", "Midi Asset Editor"));
	auto WorkspaceMenuCategoryRef = WorkspaceMenuCategory.ToSharedRef();

	FAssetEditorToolkit::RegisterTabSpawners(TabManager);

	TabManager->RegisterTabSpawner(MidiEditorTabId, FOnSpawnTab::CreateSP(this, &FMidiAssetEditorToolkit::HandleTabManagerSpawnTab, MidiEditorTabId))
		.SetDisplayName(LOCTEXT("TextEditorTabName", "Midi Editor"))
		.SetGroup(WorkspaceMenuCategoryRef)
		.SetIcon(FSlateIcon(FEditorStyle::GetStyleSetName(), "LevelEditor.Tabs.Viewports"));
}


void FMidiAssetEditorToolkit::UnregisterTabSpawners(const TSharedRef<class FTabManager>& TabManager)
{
	FAssetEditorToolkit::UnregisterTabSpawners(TabManager);

	TabManager->UnregisterTabSpawner(MidiEditorTabId);
}


/* IToolkit interface
 *****************************************************************************/

FText FMidiAssetEditorToolkit::GetBaseToolkitName() const
{
	return LOCTEXT("AppLabel", "Midi Asset Editor");
}


FName FMidiAssetEditorToolkit::GetToolkitFName() const
{
	return FName("MidiAssetEditor");
}


FLinearColor FMidiAssetEditorToolkit::GetWorldCentricTabColorScale() const
{
	return FLinearColor(0.3f, 0.2f, 0.5f, 0.5f);
}


FString FMidiAssetEditorToolkit::GetWorldCentricTabPrefix() const
{
	return LOCTEXT("WorldCentricTabPrefix", "MidiAsset ").ToString();
}


/* FGCObject interface
 *****************************************************************************/

void FMidiAssetEditorToolkit::AddReferencedObjects(FReferenceCollector& Collector)
{
	Collector.AddReferencedObject(MidiAsset);
}


/* FEditorUndoClient interface
*****************************************************************************/

void FMidiAssetEditorToolkit::PostUndo(bool bSuccess)
{ }


void FMidiAssetEditorToolkit::PostRedo(bool bSuccess)
{
	PostUndo(bSuccess);
}


/* FTextAssetEditorToolkit callbacks
 *****************************************************************************/

TSharedRef<SDockTab> FMidiAssetEditorToolkit::HandleTabManagerSpawnTab(const FSpawnTabArgs& Args, FName TabIdentifier)
{
	TSharedPtr<SWidget> TabWidget = SNullWidget::NullWidget;

	if (TabIdentifier == MidiEditorTabId)
	{
		TabWidget = SNew(SMidiAssetEditor, MidiAsset, Style);
	}

	return SNew(SDockTab)
		.TabRole(ETabRole::PanelTab)
		[
			TabWidget.ToSharedRef()
		];
}


#undef LOCTEXT_NAMESPACE
