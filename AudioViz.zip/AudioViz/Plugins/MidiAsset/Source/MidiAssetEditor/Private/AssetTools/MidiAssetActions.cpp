// Copyright 1998-2015 Epic Games, Inc. All Rights Reserved.

#include "MidiAssetEditorPrivatePCH.h"
#include "ContentBrowserModule.h"


#define LOCTEXT_NAMESPACE "AssetTypeActions"


/* FMidiAssetActions constructors
 *****************************************************************************/

FMidiAssetActions::FMidiAssetActions(const TSharedRef<ISlateStyle>& InStyle)
	: Style(InStyle)
{ }


/* FAssetTypeActions_Base overrides
 *****************************************************************************/

bool FMidiAssetActions::CanFilter()
{
	return true;
}


void FMidiAssetActions::GetActions(const TArray<UObject*>& InObjects, FMenuBuilder& MenuBuilder)
{
	FAssetTypeActions_Base::GetActions(InObjects, MenuBuilder);

	auto MidiAssets = GetTypedWeakObjectPtrs<UMidiAsset>(InObjects);

	MenuBuilder.AddMenuEntry(
		LOCTEXT("MidiAsset_ReverseText", "Reverse Text"),
		LOCTEXT("MidiAsset_ReverseTextToolTip", "Reverse the text stored in the selected text asset(s)."),
		FSlateIcon(),
		FUIAction(
			FExecuteAction::CreateLambda([=]{
				for (auto& MidiAsset : MidiAssets)
				{
					if (MidiAsset.IsValid() && !MidiAsset->Text.IsEmpty())
					{
						MidiAsset->Text = FText::FromString(MidiAsset->Text.ToString().Reverse());
						MidiAsset->PostEditChange();
					}
				}
			}),
			FCanExecuteAction::CreateLambda([=] {
				for (auto& MidiAsset : MidiAssets)
				{
					if (MidiAsset.IsValid() && !MidiAsset->Text.IsEmpty())
					{
						return true;
					}
				}
				return false;
			})
		)
	);
}


uint32 FMidiAssetActions::GetCategories()
{
	return EAssetTypeCategories::Misc;
}


FText FMidiAssetActions::GetName() const
{
	return NSLOCTEXT("AssetTypeActions", "AssetTypeActions_MidiAsset", "Midi Asset");
}


UClass* FMidiAssetActions::GetSupportedClass() const
{
	return UMidiAsset::StaticClass();
}


FColor FMidiAssetActions::GetTypeColor() const
{
	return FColor::White;
}


bool FMidiAssetActions::HasActions(const TArray<UObject*>& InObjects) const
{
	return true;
}


void FMidiAssetActions::OpenAssetEditor(const TArray<UObject*>& InObjects, TSharedPtr<class IToolkitHost> EditWithinLevelEditor)
{
	EToolkitMode::Type Mode = EditWithinLevelEditor.IsValid()
		? EToolkitMode::WorldCentric
		: EToolkitMode::Standalone;

	for (auto ObjIt = InObjects.CreateConstIterator(); ObjIt; ++ObjIt)
	{
		auto MidiAsset = Cast<UMidiAsset>(*ObjIt);

		if (MidiAsset != nullptr)
		{
			TSharedRef<FMidiAssetEditorToolkit> EditorToolkit = MakeShareable(new FMidiAssetEditorToolkit(Style));
			EditorToolkit->Initialize(MidiAsset, Mode, EditWithinLevelEditor);
		}
	}
}


#undef LOCTEXT_NAMESPACE
