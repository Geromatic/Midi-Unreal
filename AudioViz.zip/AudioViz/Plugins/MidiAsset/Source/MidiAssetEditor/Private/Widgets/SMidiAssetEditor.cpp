// Copyright 1998-2015 Epic Games, Inc. All Rights Reserved.

#include "MidiAssetEditorPrivatePCH.h"
#include "SMultiLineEditableTextBox.h"


#define LOCTEXT_NAMESPACE "SMidiAssetEditor"


/* SMidiAssetEditor interface
 *****************************************************************************/

SMidiAssetEditor::~SMidiAssetEditor()
{
	FCoreUObjectDelegates::OnObjectPropertyChanged.RemoveAll(this);
}


void SMidiAssetEditor::Construct(const FArguments& InArgs, UMidiAsset* InMidiAsset, const TSharedRef<ISlateStyle>& InStyle)
{
	MidiAsset = InMidiAsset;

	ChildSlot
	[
		SNew(SVerticalBox)

		+ SVerticalBox::Slot()
			.FillHeight(1.0f)
			[
				SAssignNew(EditableTextBox, SMultiLineEditableTextBox)
					.OnTextChanged(this, &SMidiAssetEditor::HandleEditableTextBoxTextChanged)
					.OnTextCommitted(this, &SMidiAssetEditor::HandleEditableTextBoxTextCommitted)
					.Text(MidiAsset->Text)
			]
	];

	FCoreUObjectDelegates::OnObjectPropertyChanged.AddSP(this, &SMidiAssetEditor::HandleTextAssetPropertyChanged);
}


/* SMidiAssetEditor callbacks
 *****************************************************************************/

void SMidiAssetEditor::HandleEditableTextBoxTextChanged(const FText& NewText)
{
	MidiAsset->MarkPackageDirty();
}


void SMidiAssetEditor::HandleEditableTextBoxTextCommitted(const FText& Comment, ETextCommit::Type CommitType)
{
	MidiAsset->Text = EditableTextBox->GetText();
}


void SMidiAssetEditor::HandleTextAssetPropertyChanged(UObject* Object, FPropertyChangedEvent& PropertyChangedEvent)
{
	if (Object == MidiAsset)
	{
		EditableTextBox->SetText(MidiAsset->Text);
	}
}


#undef LOCTEXT_NAMESPACE
