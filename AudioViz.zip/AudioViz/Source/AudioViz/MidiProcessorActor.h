// Copyright -> Scott Bishel

#pragma once

#include "Midi/MidiFile.h"
#include "Midi/Event/MidiEvent.h"
#include "Midi/Util/MidiProcessor.h"

#include "GameFramework/Actor.h"
#include "MidiProcessorActor.generated.h"

UCLASS()
class AUDIOVIZ_API AMidiProcessorActor : public AActor
{
	GENERATED_BODY()

public:	
	// Sets default values for this actor's properties
	AMidiProcessorActor();
	~AMidiProcessorActor();
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;
	
	// Called every frame
	virtual void Tick( float DeltaSeconds ) override;

	UFUNCTION(BlueprintCallable, Category = "Midi Processor")
	void initialize(const TArray<uint8>& midiData);

	UFUNCTION(BlueprintCallable, Category = "Midi Processor")
	USoundWave* ConstantNote(float frequency = 440.0);

// Other
//-----------------------

private:
	MidiFile* mMidiFile;
	bool mRunning;
	double mTicksElapsed;
	long mMsElapsed;

	int mMPQN;
	int mPPQ;

	MetronomeTick* mMetronome;
public:
	UFUNCTION(BlueprintCallable, Category = "Midi Processor")
	void start();
	UFUNCTION(BlueprintCallable, Category = "Midi Processor")
	void stop();
	UFUNCTION(BlueprintCallable, Category = "Midi Processor")
	void reset();

	UFUNCTION(BlueprintCallable, Category = "Midi Processor")
	bool isStarted();
	UFUNCTION(BlueprintCallable, Category = "Midi Processor")
	bool isRunning();

	void process();

protected:
	UFUNCTION(BlueprintImplementableEvent, Category = "Midi Processor")
		void onStart(bool fromBeginning);

	UFUNCTION(BlueprintImplementableEvent, Category = "Midi Processor")
		void onStop(bool finished);

	UFUNCTION(BlueprintImplementableEvent, Category = "Midi Processor")
		void onEvent(int32 track, int32 note, int32 velocity, int32 elapsed);

	void dispatch(MidiEvent * _event);

private:
	TArray<TArray<MidiEvent*>::TIterator> mCurrEvents;
	long mLastMs;
//-----------------------------------------

};
