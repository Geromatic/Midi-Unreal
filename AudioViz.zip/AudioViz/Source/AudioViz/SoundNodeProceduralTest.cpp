// Copyright -> Scott Bishel

#include "AudioViz.h"
#include "SoundNodeProceduralTest.h"

USoundNodeProceduralTest::USoundNodeProceduralTest(const FObjectInitializer& PCIP)
	: Super(PCIP)
	, Volume(0.5f)
	, Frequency(100.0f)
{
	SoundWaveProcedural = nullptr;
}

int32 USoundNodeProceduralTest::GetMaxChildNodes() const
{
	return 0;
}

float USoundNodeProceduralTest::GetDuration()
{
	return INDEFINITELY_LOOPING_DURATION;
}

void USoundNodeProceduralTest::ParseNodes(FAudioDevice* AudioDevice, const UPTRINT NodeWaveInstanceHash, FActiveSound& ActiveSound, const FSoundParseParameters& ParseParams, TArray<FWaveInstance*>& WaveInstances)
{
	// method 1 : works "sort of" , but seems like the clip stops playing and restarts
	if (!SoundWaveIsInitialized)
	{
		CreateSoundWaveStreaming();
	}

	if (SoundWaveIsInitialized)
	{
		if (SoundWaveProcedural)
		{
			SoundWaveProcedural->Frequency = Frequency;
			SoundWaveProcedural->Volume = Volume;
			try {
				SoundWaveProcedural->Parse(AudioDevice, NodeWaveInstanceHash, ActiveSound, ParseParams, WaveInstances);
			}
			catch (...) {
			}
			//SoundWaveProcedural->Parse(AudioDevice, NodeWaveInstanceHash, ActiveSound, ParseParams, WaveInstances);
		}
	}
}


void USoundNodeProceduralTest::CreateSoundWaveStreaming()
{
	SoundWaveProcedural = NewObject<USoundWaveProceduralTest>();
	SoundWaveIsInitialized = true;
}
