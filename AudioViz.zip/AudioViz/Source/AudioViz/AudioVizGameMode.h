// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "GameFramework/GameMode.h"
#include "AudioVizGameMode.generated.h"

/**
 * 
 */
UCLASS()
class AUDIOVIZ_API AAudioVizGameMode : public AGameMode
{
	GENERATED_BODY()
	
	
	
	
};
