// Copyright -> Scott Bishel

#include "AudioViz.h"
#include "MyUtils.h"

#include <cmath>
#include <fstream>
#include <iostream>
#include <sstream>
using namespace std;

#include "Sound/SoundWaveProcedural.h"

namespace little_endian_io
{
	template <typename Word>
	std::stringstream& write_word(std::stringstream& outs, Word value, unsigned size = sizeof(Word))
	{
		for (; size; --size, value >>= 8)
			outs.put(static_cast <char> (value & 0xFF));
		return outs;
	}
}
using namespace little_endian_io;

USoundWave* UMyUtils::CreateSoundWaveFromBuffer(uint8* buffer, int32 size)
{
	USoundWaveProcedural* sw = NewObject<USoundWaveProcedural>(USoundWaveProcedural::StaticClass());

	if (!sw)
		return nullptr;

	sw->SampleRate = 44100;
	sw->NumChannels = 2;

	int32 DurationDiv = sw->NumChannels * 16 * sw->SampleRate;
	if (DurationDiv)
		sw->Duration = size * 8.0f / DurationDiv;
	else
		sw->Duration = 0.0f;

	sw->RawPCMDataSize = size;
	sw->SoundGroup = SOUNDGROUP_Default;
	sw->QueueAudio(buffer, size);

	return sw;
}

USoundWave* UMyUtils::CreateSoundWave(const TArray<int>& buffer)
{
	std::stringstream f;

	for (long i = 0; i < buffer.Num(); i++) {
		write_word(f, buffer[i], 2);
	}

	const std::string& tmp = f.str();
	return CreateSoundWaveFromBuffer((uint8*)tmp.c_str(), tmp.size());;
}

USoundWave* UMyUtils::AudioNote(float amplitude, float frequency, float seconds)
{
	std::stringstream f;

	double hz = 44100;    // samples per second

	int N = hz * seconds;  // total number of samples
	for (int s = 0; s < N; s++) {
		int value = amplitude * sin( (2 * PI * frequency) * ((double)s / hz));
		if (value < 0)
			value = 0;
		write_word(f, value, 2);
	}

	const std::string& tmp = f.str();
	return CreateSoundWaveFromBuffer((uint8*)tmp.c_str(), tmp.size());

	//TArray<int> data;

	//double hz = 44100;    // samples per second

	//int N = hz * seconds;  // total number of samples
	//for (int s = 0; s < N; s++) {
	//	int value = amplitude * sin(2 * PI * frequency * ((double)s / hz));
	//	data.Add(value);
	//}

	//return CreateSoundWave(data);
}