// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "GameFramework/Actor.h"
#include "MidiActor.generated.h"

UCLASS()
class AUDIOVIZ_API AMidiActor : public AActor
{
	GENERATED_BODY()
	
public:	
	// Sets default values for this actor's properties
	AMidiActor();

	// Called when the game starts or when spawned
	virtual void BeginPlay() override;
	
	// Called every frame
	virtual void Tick( float DeltaSeconds ) override;

private:
	TArray<int> midiList;

public:
	//UPROPERTY(EditAnywhere, BlueprintReadWrite)
	float sampleRate;

	UFUNCTION(BlueprintCallable, Category = "Midi")
		void create(float amplitude = 16384.0, float frequency = 440.0, float duration = 1);

	UFUNCTION(BlueprintCallable, Category = "Midi")
		void reset();

	UFUNCTION(BlueprintCallable, Category = "Midi")
		static USoundWave* TestWave();

	UFUNCTION(BlueprintCallable, Category = "Midi")
		USoundWave* GenerateSoundWave();
	
};
