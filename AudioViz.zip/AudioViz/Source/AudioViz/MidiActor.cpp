// Fill out your copyright notice in the Description page of Project Settings.

#include "AudioViz.h"
#include "MidiActor.h"
#include "MyUtils.h"

#include <cmath>
#include <fstream>
#include <iostream>
#include <sstream>
using namespace std;

// Sets default values
AMidiActor::AMidiActor()
{
	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;
	this->sampleRate = 44100.0;
}

// Called when the game starts or when spawned
void AMidiActor::BeginPlay()
{
	Super::BeginPlay();
}

// Called every frame
void AMidiActor::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}

//-------------------------------------------------------------------------

void AMidiActor::create(float amplitude, float frequency, float duration)
{
	if (duration < 0)
		return;

	int N = this->sampleRate * duration;  // total number of samples
	for (int s = 0; s < N; s++) {
		int note = amplitude * sin( (2 * PI * frequency) * ((double)s / this->sampleRate));

		this->midiList.Add(note);
	}

}

void AMidiActor::reset() {
	midiList.Empty();
}

USoundWave* AMidiActor::TestWave() {

	TArray < int > data;

	// Write the audio samples
	// (We'll generate a single C4 note with a sine wave, fading from left to right)
	const double two_pi = 6.283185307179586476925286766559;
	const double max_amplitude = 32760;  // "volume"

	double hz = 44100;    // samples per second
	double frequency = 261.626;  // middle C
	double seconds = 2.5;      // time

	int N = hz * seconds;  // total number of samples
	for (int n = 0; n < N; n++)
	{
		double amplitude = (double)n / N * max_amplitude;
		double value = sin((two_pi * n * frequency) / hz);
		data.Add((int)(amplitude  * value));
		data.Add((int)((max_amplitude - amplitude) * value));
	}

	return UMyUtils::CreateSoundWave(data);
}


USoundWave* AMidiActor::GenerateSoundWave()
{
	return UMyUtils::CreateSoundWave(midiList);
}
