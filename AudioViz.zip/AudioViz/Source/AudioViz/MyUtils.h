// Copyright -> Scott Bishel

#pragma once

#include "Kismet/BlueprintFunctionLibrary.h"
#include "MyUtils.generated.h"

/**
 * 
 */
UCLASS()
class AUDIOVIZ_API UMyUtils : public UBlueprintFunctionLibrary
{
	GENERATED_BODY()
	
public:

	static USoundWave* CreateSoundWave(const TArray<int>& buffer);
	static USoundWave* CreateSoundWaveFromBuffer(uint8* buffer, int32 size);

	UFUNCTION(BlueprintCallable, Category = "Midi")
	static USoundWave* AudioNote(float amplitude = 16384.0, float frequency = 440.0, float seconds = 1.0);
};
