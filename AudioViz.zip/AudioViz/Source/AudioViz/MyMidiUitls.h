// Copyright -> Scott Bishel

#pragma once

#include "Kismet/BlueprintFunctionLibrary.h"
#include "MyMidiUitls.generated.h"

/**
 * 
 */
UCLASS()
class AUDIOVIZ_API UMyMidiUitls : public UBlueprintFunctionLibrary
{
	GENERATED_BODY()

public:

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Midi")
		static void GetMidiItem(int32 noteNum, int32& octave, FString& note);

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Midi")
		static float MidiNoteToFrequency(int32 midiNote);
	static int32 FrequencyToMidiNote(float Frequency);

	UFUNCTION(BlueprintCallable, Category = "Midi")
	static FString ParseMidiPreview(const TArray<uint8>& data);
	
};
