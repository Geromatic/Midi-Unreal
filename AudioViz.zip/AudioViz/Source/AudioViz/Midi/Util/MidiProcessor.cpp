// Copyright -> Scott Bishel

#include "AudioViz.h"
#include "MidiProcessor.h"

#include "../Event/Meta/Tempo.h"
#include "../Event/Meta/TimeSignature.h"
#include "../Event/MidiEvent.h"
#include "../Util/MidiUtil.h"

#include <time.h>
#include <sstream>
#include <sys/timeb.h>

using namespace std;

unsigned long CALLBACK PosixThreadMainRoutine(LPVOID lpThreadData)
{
	MidiProcessor * process = (MidiProcessor*)lpThreadData;
	// Do some work here.
	process->process();
	return 0;
}

MidiProcessor::MidiProcessor(MidiFile & input) {
	mMidiFile = input;

	mRunning = false;
	mTicksElapsed = 0;
	mMsElapsed = 0;

	mMPQN = Tempo::DEFAULT_MPQN();
	mPPQ = mMidiFile.getResolution();
}

MidiProcessor::~MidiProcessor()
{
}

void MidiProcessor::start() {
	if (mRunning) return;
	mRunning = true;

	mThread = CreateThread(NULL, NULL, PosixThreadMainRoutine, this, NULL, NULL);
}

void MidiProcessor::stop() {
	mRunning = false;
}

void MidiProcessor::reset() {
	mRunning = false;
	mTicksElapsed = 0;
}

bool MidiProcessor::isStarted() {
	return mTicksElapsed > 0;
}
bool MidiProcessor::isRunning() {
	return mRunning;
}

void MidiProcessor::onStart(bool fromBeginning) {
	TMap<FString, TArray<MidiEventListener*>>::TIterator it = mEventListenerMap.CreateIterator();

	while (it) {
		TPair<FString, TArray<MidiEventListener*>> item = *it;
		TArray<MidiEventListener*>& listeners = item.Value;

		for (int i = 0; i < listeners.Num(); i++)
		{
			listeners[i]->onStart(fromBeginning);
		}
		++it;
	}
	for (int i = 0; i < mListenersToAll.Num(); i++)
	{
		mListenersToAll[i]->onStart(fromBeginning);
	}
}

void MidiProcessor::onStop(bool finished) {

	TMap<FString, TArray<MidiEventListener*>>::TIterator it = mEventListenerMap.CreateIterator();

	while (it) {
		TPair<FString, TArray<MidiEventListener*>> item = *it;
		TArray<MidiEventListener*>& listeners = item.Value;

		for (int i = 0; i < listeners.Num(); i++)
		{
			listeners[i]->onStop(finished);
		}
		++it;
	}
	for (int i = 0; i < mListenersToAll.Num(); i++)
	{
		mListenersToAll[i]->onStop(finished);
	}
}

void MidiProcessor::registerListenerForAllEvents(MidiEventListener* mel) {
	mListenersToAll.Add(mel);
}
void MidiProcessor::unregisterListenerForAllEvents(MidiEventListener* mel) {
	mListenersToAll.Remove(mel);
}

void MidiProcessor::registerEventListener(MidiEventListener* mel, class MidiEvent* _event)
{
	TArray<MidiEventListener*>* listeners = mEventListenerMap.Find(typeid(_event).name());

	if (&listeners == NULL) {

		TArray<MidiEventListener*>& listener = mEventListenerMap.Add(typeid(_event).name());
		listener.Add(mel);
	}
	else {
		listeners->Add(mel);
	}
}

void MidiProcessor::unregisterEventListener(MidiEventListener* mel, class MidiEvent* _event)
{
	mEventListenerMap.Remove(typeid(_event).name());

	TArray<MidiEventListener*>* listeners = mEventListenerMap.Find(typeid(_event).name());

	if (&listeners == NULL) {

		listeners->Remove(mel);
	}
}

void MidiProcessor::unregisterAllEventListeners() {
	mEventListenerMap.Empty();
	mListenersToAll.Empty();
}

void MidiProcessor::dispatch(MidiEvent * _event) {

	// Tempo and Time Signature events are always needed by the processor
	if (_event->getType() == (MetaEvent::TEMPO & 0XFF) ) {
		mMPQN = (static_cast<Tempo*>(_event))->getMpqn();
	}

	else if (_event->getType() == (MetaEvent::TIME_SIGNATURE & 0XFF)) {
		//metronome->setMetronomeFrequency((static_cast<TimeSignature*>(_event))->getMeter());
	}

	for (int i = 0; i < mListenersToAll.Num(); i++)
	{
		mListenersToAll[i]->onEvent(_event, mMsElapsed);
	}

	// Retrieve all listeners associated with this event and send them the event
	TArray<MidiEventListener*> * listeners = mEventListenerMap.Find(typeid(_event).name());

	if (listeners != NULL) {
		TArray<MidiEventListener*>::TIterator it = listeners->CreateIterator();
		while (it) {
			MidiEventListener* mel = *it;
			mel->onEvent(_event, mMsElapsed);
			++it;
	    }
	}
}

//
//long long milliseconds_now() {
//	static LARGE_INTEGER s_frequency;
//	static BOOL s_use_qpc = QueryPerformanceFrequency(&s_frequency);
//	if (s_use_qpc) {
//		LARGE_INTEGER now;
//		QueryPerformanceCounter(&now);
//		return (1000LL * now.QuadPart) / s_frequency.QuadPart;
//	}
//	else {
//		return GetTickCount();
//	}
//}

void MidiProcessor::process() {

	onStart(mTicksElapsed < 1);

	TArray<MidiTrack*>& tracks = mMidiFile.getTracks();

	TArray<TArray<MidiEvent*>::TIterator> currEvents;
	for (int i = 0; i < tracks.Num(); i++) {
		currEvents.Add( mMidiFile.getTracks()[i]->getEvents().CreateIterator());
	}

	long lastMs = milliseconds_now();

	bool finished = false;

top:
	while (mRunning) {
		long now = milliseconds_now();
		long msElapsed = now - lastMs;
		if (msElapsed < PROCESS_RATE_MS) {
			Sleep(1);
			continue;
		}

		double ticksElapsed = MidiUtil::msToTicks(msElapsed, mMPQN, mPPQ);

		if (ticksElapsed < 1) {
			continue;
		}

		lastMs = now;
		mMsElapsed += msElapsed;
		mTicksElapsed += ticksElapsed;

		for (int i = 0; i < tracks.Num(); i++) {
			while (currEvents[i]) {
				MidiEvent * _event = *currEvents[i];
				if (_event->getTick() <= mTicksElapsed) {
					dispatch(_event);
					currEvents[i]++;
				}
				else
					break;
			}
		}

		for (int i = 0; i < tracks.Num(); i++) {
			if (currEvents[i])
			{
				goto top;
			}
		}

		finished = true;
		break;
	}

	mRunning = false;
	onStop(finished);
}
