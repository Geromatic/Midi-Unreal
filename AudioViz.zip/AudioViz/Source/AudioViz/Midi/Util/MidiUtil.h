// Copyright -> Scott Bishel

#pragma once

/**
 * 
 */
class AUDIOVIZ_API MidiUtil
{

public:
	static long ticksToMs(long ticks, int mpqn, int resolution);
	static long ticksToMs(long ticks, float bpm, int resolution);

	static double msToTicks(long ms, int mpqn, int ppq);
	static double msToTicks(long ms, float bpm, int ppq);

	static int bpmToMpqn(float bpm);
	static float mpqnToBpm(int mpqn);

	static int bytesToInt(char buff[], int off, int len);

	static char* intToBytes(int val, int charCount);

	static bool bytesEqual(char buf1[], char buf2[], int off, int len);

	static char* extractBytes(char buffer[], int off, int len);

private:
	static const char HEX[];

public:
	static std::string byteToHex(char b);
	static std::string bytesToHex(char b[]);

};

#ifdef _WINDOWS
#include <sstream>
#include <vector>
template<typename T>
class TArray {
	std::vector<T> data;

	void Add(const T& item) {
		data.push_back(item);
	}
	void Remove(const T& item) {
		for (unsigned i = 0; i < data.size(); i++) {
			if (myvector.at(i) == item) {
				data.erase(data.begin() + i);
				break;
			}
		}
	}

	void RemoveAt(int index) {
		data.erase(data.begin() + index);
	}

	void Empty() {
		data.clear();
	}
};


class FArchive {
protected:
	std::stringstream ss;
public:
	virtual void Serialize(void* data, int size) {}

	void Close() {
	}
};

class FBufferReader : public FArchive {
public:
	FBufferReader(void* data, int size) {
		ss.write((char*)data, size);
	}

	void Serialize(void* data, int size) {
		ss.read((char*)data, size);
	}
};

class FMemoryWriter : public _FArchive {
public:
	FMemoryWriter(const TArray<uint8>& buffer) {
	}

	void Serialize(void* data, int size) {
		ss.write((char*)data, size);
	}
};
#endif