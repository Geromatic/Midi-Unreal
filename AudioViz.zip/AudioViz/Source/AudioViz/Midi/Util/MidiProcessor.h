// Copyright -> Scott Bishel

#pragma once

#include "../MidiFile.h"
#include "MidiEventListener.h"

#include <iostream>
using namespace std;

/**
 * 
 */
class AUDIOVIZ_API MidiProcessor
{
#define PROCESS_RATE_MS 8

	TMap<FString, TArray<MidiEventListener*>> mEventListenerMap;
	TArray<MidiEventListener*> mListenersToAll;

	MidiFile mMidiFile;
	bool mRunning;
	double mTicksElapsed;
	long mMsElapsed;

	int mMPQN;
	int mPPQ;

	/** Thread to run the worker FRunnable on */
	HANDLE mThread;

public:
	MidiProcessor(MidiFile & input);
	~MidiProcessor();

	void start();
	void stop();
	void reset();

	bool isStarted();
	bool isRunning();

	void registerListenerForAllEvents(MidiEventListener* mel);
	void unregisterListenerForAllEvents(MidiEventListener* mel);

	void registerEventListener(MidiEventListener* mel,  MidiEvent* _event);
	void unregisterEventListener(MidiEventListener* mel, MidiEvent* _event);

	void unregisterAllEventListeners();

	void process();

protected:
	void onStart(bool fromBeginning);
	void onStop(bool finished);

	void dispatch(MidiEvent * _event);
};

#include "../Event/MidiEvent.h"
#include "../Event/Meta/TimeSignature.h"
class MetronomeTick : public MidiEvent
{
	int mResolution;
	TimeSignature* mSignature;

	int mCurrentMeasure;
	int mCurrentBeat;

	double mMetronomeProgress;
	int mMetronomeFrequency;

public:
	MetronomeTick(TimeSignature* sig, int resolution) : MidiEvent(0, 0)
	{
		mResolution = resolution;

		setTimeSignature(sig);
		mCurrentMeasure = 1;
	}

	void setTimeSignature(TimeSignature* sig)
	{
		mSignature = sig;
		mCurrentBeat = 0;

		setMetronomeFrequency(sig->getMeter());
	}

	bool update(double ticksElapsed)
	{
		mMetronomeProgress += ticksElapsed;

		if (mMetronomeProgress >= mMetronomeFrequency)
		{
			mMetronomeProgress = FMath::Fmod(mMetronomeProgress, mMetronomeFrequency);

			mCurrentBeat = (mCurrentBeat + 1) % mSignature->getNumerator();
			if (mCurrentBeat == 0)
			{
				mCurrentMeasure++;
			}

			return true;
		}
		return false;
	}

	void setMetronomeFrequency(int meter)
	{
		switch (meter)
		{
		case TimeSignature::METER_EIGHTH:
			mMetronomeFrequency = mResolution / 2;
			break;
		case TimeSignature::METER_QUARTER:
			mMetronomeFrequency = mResolution;
			break;
		case TimeSignature::METER_HALF:
			mMetronomeFrequency = mResolution * 2;
			break;
		case TimeSignature::METER_WHOLE:
			mMetronomeFrequency = mResolution * 4;
			break;
		}
	}

	int getBeatNumber()
	{
		return mCurrentBeat + 1;
	}

	int getMeasure()
	{
		return mCurrentMeasure;
	}

	std::string ToString()
	{
		std::stringstream ss;
		ss << "Metronome: " << mCurrentMeasure << "\t" << getBeatNumber();
		return ss.str();
	}

	int CompareTo(MidiEvent* o)
	{
		return 0;
	}
protected:
	int getEventSize()
	{
		return 0;
	}

	int getSize()
	{
		return 0;
	}
};
