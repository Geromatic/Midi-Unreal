// Copyright -> Scott Bishel

#pragma once

#include "ChannelEvent.h"

/**
 * 
 */
class AUDIOVIZ_API ChannelAftertouch : public ChannelEvent
{
public:
	ChannelAftertouch(long tick, int channel, int amount);
	ChannelAftertouch(long tick, long delta, int channel, int amount);

	int getAmount();
	void setAmount(int p);
};
