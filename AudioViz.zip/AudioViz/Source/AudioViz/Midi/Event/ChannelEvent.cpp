// Copyright -> Scott Bishel

#include "AudioViz.h"
#include "ChannelEvent.h"

#include "ChannelAftertouch.h"
#include "ChannelEvent.h"
#include "CController.h"
#include "NoteAftertouch.h"
#include "NoteOff.h"
#include "NoteOn.h"
#include "PitchBend.h"
#include "ProgramChange.h"
#include "SystemExclusiveEvent.h"

#include "Meta/MetaEvent.h"

ChannelEvent::ChannelEvent(long tick, int type, int channel, int param1, int param2)
	: MidiEvent(tick, 0)
{
	mType = type & 0x0F;
	mChannel = channel & 0x0F;
	mValue1 = param1 & 0xFF;
	mValue2 = param2 & 0xFF;
}
ChannelEvent::ChannelEvent(long tick, long delta, int type, int channel, int param1, int param2) : MidiEvent(tick, delta) {

	mType = type & 0x0F;
	mChannel = channel & 0x0F;
	mValue1 = param1 & 0xFF;
	mValue2 = param2 & 0xFF;
}

//int ChannelEvent::getType() {
//	return mType;
//}

void ChannelEvent::setChannel(int c) {
	if (c < 0) {
		c = 0;
	}
	else if (c > 15) {
		c = 15;
	}
	mChannel = c;
}
int ChannelEvent::getChannel() {
	return mChannel;
}

int ChannelEvent::getEventSize() {
	switch (mType) {
	case PROGRAM_CHANGE:
	case CHANNEL_AFTERTOUCH:
		return 2;
	default:
		return 3;
	}
}

bool ChannelEvent::requiresStatusByte(MidiEvent * prevEvent) {
	if (prevEvent == NULL) {
		return true;
	}
	
	if (!(typeid(prevEvent) == typeid(ChannelEvent))) {
		return true;
	}

	ChannelEvent * ce = static_cast<ChannelEvent*>(prevEvent);
	return !(mType == ce->getType() && mChannel == ce->getChannel());
}

void ChannelEvent::writeToFile(FMemoryWriter & output, bool writeType){
	MidiEvent::writeToFile(output, writeType);

	if (writeType) {
		int typeChannel = (mType << 4) + mChannel;
		output.Serialize((char*)typeChannel, 1);
	}

	output.Serialize((char*)mValue1, 1);
	if (mType != PROGRAM_CHANGE && mType != CHANNEL_AFTERTOUCH) {
		output.Serialize((char*)mValue2, 1);
	}
}
ChannelEvent * ChannelEvent::parseChannelEvent(long tick, long delta, int type, int channel, FBufferReader & input) {

	int val1 = 0;
	input.Serialize(&val1, 1);
	int val2 = 0;
	if (type != PROGRAM_CHANGE && type != CHANNEL_AFTERTOUCH) {
		input.Serialize(&val2, 1);
	}

	switch (type) {
	case NOTE_OFF:
		return new NoteOff(tick, delta, channel, val1, val2);
	case NOTE_ON:
		return new NoteOn(tick, delta, channel, val1, val2);
	case NOTE_AFTERTOUCH:
		return new NoteAfterTouch(tick, delta, channel, val1, val2);
	case CONTROLLER:
		return new CController(tick, delta, channel, val1, val2);
	case PROGRAM_CHANGE:
		return new ProgramChange(tick, delta, channel, val1);
	case CHANNEL_AFTERTOUCH:
		return new ChannelAftertouch(tick, delta, channel, val1);
	case PITCH_BEND:
		return new PitchBend(tick, delta, channel, val1, val2);
	default:
		return new ChannelEvent(tick, delta, type, channel, val1, val2);
	}
}