// Copyright -> Scott Bishel

#include "AudioViz.h"
#include "SystemExclusiveEvent.h"

SystemExclusiveEvent::SystemExclusiveEvent(int type, long tick, char data[])
	: MidiEvent(tick, 0), mData(NULL), mLength(NULL)
{
	mType = type & 0xFF;
	if (mType != 0xF0 && mType != 0xF7) {
		mType = 0xF0;
	}

	mLength = new VariableLengthInt(sizeof(&data));
	mData = data;
}

SystemExclusiveEvent::SystemExclusiveEvent(int type, long tick, long delta, char data[])
	: MidiEvent(tick, delta), mData(NULL), mLength(NULL)
{

	mType = type & 0xFF;
	if (mType != 0xF0 && mType != 0xF7) {
		mType = 0xF0;
	}

	mLength = new VariableLengthInt(sizeof(&data));
	mData = data;
}

SystemExclusiveEvent::~SystemExclusiveEvent()
{
	if (mLength != NULL)
		delete mLength;
	if (mData != NULL)
		delete[] mData;
}

char* SystemExclusiveEvent::getData() {
	return mData;
}
void SystemExclusiveEvent::setData(char data[]) {
	if (mData != NULL)
	{
		delete[] mData;
		mData = NULL;
	}

	mLength->setValue(sizeof(&data));
	mData = data;
}

bool SystemExclusiveEvent::requiresStatusByte(MidiEvent* prevEvent) {
	return true;
}

void SystemExclusiveEvent::writeToFile(FMemoryWriter & output, bool writeType) {
	MidiEvent::writeToFile(output, writeType);

	if (writeType) {
		output.Serialize((char*)mType, 1);
	}
	output.Serialize(mLength->getBytes(), mLength->getByteCount());
	output.Serialize(mData, sizeof(&mData));
}

int SystemExclusiveEvent::getEventSize() {
	return 1 + mLength->getByteCount() + sizeof(&mData);
}