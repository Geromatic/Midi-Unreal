// Copyright -> Scott Bishel

#include "AudioViz.h"
#include "TextualMetaEvent.h"

TextualMetaEvent::TextualMetaEvent(long tick, long delta, int type, string text)
	: MetaEvent(tick, delta, type, new VariableLengthInt((int)text.length()))
{
	mText = text;
}

void TextualMetaEvent::setText(string t) {
	mText = t;
	mLength->setValue((int)t.length());
}
string TextualMetaEvent::getText() {
	return mText;
}

int TextualMetaEvent::getEventSize() {
	return 2 + mLength->getByteCount() + (int)mText.length();
}

void TextualMetaEvent::writeToFile(FMemoryWriter & output) {
	MetaEvent::writeToFile(output);

	output.Serialize(mLength->getBytes(), mLength->getByteCount());
	output.Serialize((char*)mText.c_str(), mText.length());
}

string TextualMetaEvent::ToString() {
	std::stringstream ss;
	ss << MetaEvent::ToString() << ": " << mText;
	return ss.str();
}