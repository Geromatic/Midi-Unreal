// Copyright -> Scott Bishel

#include "AudioViz.h"
#include "SequencerSpecificEvent.h"

#include "../../Util/MidiUtil.h"

SequencerSpecificEvent::SequencerSpecificEvent(long tick, long delta, char data[])
	: MetaEvent(tick, delta, MetaEvent::SEQUENCER_SPECIFIC, new VariableLengthInt(sizeof(&data))), mData(NULL)
{
	mData = data;
}
SequencerSpecificEvent::~SequencerSpecificEvent()
{
	if (mData != NULL)
		delete[] mData;
	mData = NULL;
}

void SequencerSpecificEvent::setData(char data[]) {
	if (mData != NULL)
		delete[] mData;
	mData = NULL;

	mData = data;
	mLength->setValue(sizeof(&mData));
}
char * SequencerSpecificEvent::getData() {
	return mData;
}

int SequencerSpecificEvent::getEventSize() {
	return 2 + mLength->getByteCount() + sizeof(&mData);
}

void SequencerSpecificEvent::writeToFile(FMemoryWriter & output) {
	MetaEvent::writeToFile(output);

	output.Serialize(mLength->getBytes(), mLength->getByteCount());
	output.Serialize(mData, sizeof(&mData));
}
