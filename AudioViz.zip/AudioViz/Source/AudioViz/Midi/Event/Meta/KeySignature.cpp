// Copyright -> Scott Bishel

#include "AudioViz.h"
#include "KeySignature.h"

KeySignature::KeySignature(long tick, long delta, int key, int scale)
	: MetaEvent(tick, delta, MetaEvent::KEY_SIGNATURE, new VariableLengthInt(2))
{
	mKey = key;
	mScale = scale;
}

void KeySignature::setKey(int key) {
	mKey = key;
}
int KeySignature::getKey() {
	return mKey;
}

void KeySignature::setScale(int scale) {
	mScale = scale;
}
int KeySignature::getScale() {
	return mScale;
}

int KeySignature::getEventSize() {
	return 5;
}

void KeySignature::writeToFile(FMemoryWriter & output) {
	MetaEvent::writeToFile(output);

	output.Serialize((char*)2, 1);
	output.Serialize((char*)mKey, 1);
	output.Serialize((char*)mScale, 1);
}

KeySignature * KeySignature::parseKeySignature(long tick, long delta, FBufferReader & input) {

	input.Seek(input.Tell() + 1);		// Size = 2;

	int key = 0, scale = 0;
	input.Serialize(&key, 1);
	input.Serialize(&scale, 1);

	return new KeySignature(tick, delta, key, scale);
}
