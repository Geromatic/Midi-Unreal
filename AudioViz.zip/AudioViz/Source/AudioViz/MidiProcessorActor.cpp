// Copyright -> Scott Bishel

#include "AudioViz.h"
#include "MidiProcessorActor.h"

#include "MyMidiUitls.h"
#include "Midi/MidiFile.h"
#include "Midi/Event/Meta/Tempo.h"
#include "Midi/Event/Meta/TimeSignature.h"
#include "Midi/Event/MidiEvent.h"
#include "Midi/Event/ChannelEvent.h"
#include "Midi/Event/NoteOn.h"
#include "Midi/Event/NoteOff.h"
#include "Midi/Util/MidiUtil.h"
#include <time.h>

#include "SoundWaveProceduralTest.h"
#include "Kismet/GameplayStatics.h"

// Sets default values
AMidiProcessorActor::AMidiProcessorActor()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;
}

AMidiProcessorActor::~AMidiProcessorActor() {
	if (mMidiFile)
		delete mMidiFile;
}

// Called when the game starts or when spawned
void AMidiProcessorActor::BeginPlay()
{
	Super::BeginPlay();
	
}

// Called every frame
void AMidiProcessorActor::Tick( float DeltaTime )
{
	Super::Tick( DeltaTime );

	process();
}

static TimeSignature sig;

void AMidiProcessorActor::initialize(const TArray<uint8>& midiData) {
	if (mRunning) return;

	if (mMidiFile)
		delete mMidiFile;

	mMidiFile = new MidiFile((uint8*)midiData.GetData(), midiData.Num());

	mRunning = false;
	mTicksElapsed = 0;
	mMsElapsed = 0;

	mMPQN = Tempo::DEFAULT_MPQN();
	mPPQ = mMidiFile->getResolution();

	mMetronome = new MetronomeTick(&sig, mPPQ);

	mCurrEvents.Empty();
	TArray<MidiTrack*>& tracks = mMidiFile->getTracks();
	for (int i = 0; i < tracks.Num(); i++) {
		mCurrEvents.Add(tracks[i]->getEvents().CreateIterator());
	}
}

USoundWave* AMidiProcessorActor::ConstantNote(float frequency) {
	USoundWaveProceduralTest* sw = NewObject<USoundWaveProceduralTest>(USoundWaveProceduralTest::StaticClass());
	sw->Frequency = frequency;
	sw->Volume = 1;
	return sw;
}
//-----------------------------------

long long milliseconds_now() {
	static LARGE_INTEGER s_frequency;
	static BOOL s_use_qpc = QueryPerformanceFrequency(&s_frequency);
	if (s_use_qpc) {
		LARGE_INTEGER now;
		QueryPerformanceCounter(&now);
		return (1000LL * now.QuadPart) / s_frequency.QuadPart;
	}
	else {
		return GetTickCount();
	}
}

void AMidiProcessorActor::start() {
	mLastMs = milliseconds_now();
	if (mRunning) return;
	onStart(mMsElapsed == 0);
	mRunning = true;
}

void AMidiProcessorActor::stop() {
	if (mRunning)
		onStop(false);
	mRunning = false;
}

void AMidiProcessorActor::reset() {
	mRunning = false;
	mTicksElapsed = 0;

	for (int i = 0; i < mCurrEvents.Num(); i++) {
		mCurrEvents[i].Reset();
	}
}

bool AMidiProcessorActor::isStarted() {
	return mTicksElapsed > 0;
}
bool AMidiProcessorActor::isRunning() {
	return mRunning;
}

static int CurrentTrack = -1;

void AMidiProcessorActor::dispatch(MidiEvent * _event) {

	// Tempo and Time Signature events are always needed by the processor
	if (_event->getType() == (MetaEvent::TEMPO & 0XFF)) {
		mMPQN = (static_cast<Tempo*>(_event))->getMpqn();
	}

	else if (_event->getType() == (MetaEvent::TIME_SIGNATURE & 0XFF)) {
		bool shouldDispatch = mMetronome->getBeatNumber() != 1;
		mMetronome->setTimeSignature(static_cast<TimeSignature*>(_event));

		if (shouldDispatch)
		{
			dispatch(mMetronome);
		}
	}
	//	onEvent(*_event, mMsElapsed);

	// TODO
	if (_event->getType() == (ChannelEvent::NOTE_ON & 0x0F)) {
		NoteOn* note = (NoteOn*)_event;
		onEvent(CurrentTrack, note->getNoteValue(), note->getVelocity(), 0);
	}

	if (_event->getType() == (ChannelEvent::NOTE_OFF & 0x0F)) {
		NoteOff* note = (NoteOff*)_event;
		onEvent(CurrentTrack, note->getNoteValue(), 0,  0);
	}
}

void AMidiProcessorActor::process() {

	if (!mRunning)
		return;

	long now = milliseconds_now();
	long msElapsed = now - mLastMs;
	double ticksElapsed = MidiUtil::msToTicks(msElapsed, mMPQN, mPPQ);

	if (ticksElapsed < 1) {
		return;
	}

	if (mMetronome->update(ticksElapsed))
	{
		dispatch(mMetronome);
	}

	mLastMs = now;
	mMsElapsed += msElapsed;
	mTicksElapsed += ticksElapsed;

	for (int i = 0; i < mCurrEvents.Num(); i++) {
		while (mCurrEvents[i]) {
			MidiEvent * _event = *mCurrEvents[i];
			if (_event->getTick() <= mTicksElapsed) {

				CurrentTrack = i;

				dispatch(_event);
				mCurrEvents[i]++;
			}
			else
				break;
		}
	}

	int checker = 0;
	for (int i = 0; i < mCurrEvents.Num(); i++) {
		if (!mCurrEvents[i])
		{
			checker++;
		}
	}
	if (checker >= mCurrEvents.Num()) {
		mRunning = false;
		onStop(true);
	}
}