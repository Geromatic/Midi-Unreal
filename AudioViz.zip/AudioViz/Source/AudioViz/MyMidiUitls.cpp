// Copyright -> Scott Bishel

#include "AudioViz.h"
#include "MyMidiUitls.h"

#include "Midi/MidiFile.h"
#include "Midi/Event/ChannelEvent.h"
#include "Midi/Event/NoteOn.h"
#include "Midi/Event/NoteOff.h"

//static float midi[127];
//int a = 440; // a is 440 hz...
//for (int x = 0; x < 127; ++x)
//{
//	midi[x] = (a / 32) * (2 ^ ((x - 9) / 12));
//}

void UMyMidiUitls::GetMidiItem(int32 noteNum, int32& octave, FString& note) {
	octave = int32(noteNum / 12) - 1;
	note = FString("C C#D D#E F F#G G#A A#B ").Mid((noteNum % 12) * 2, 2);
}

float UMyMidiUitls::MidiNoteToFrequency(int32 midiNote) {
	//	Hertz = 440.0 * pow(2.0, (midi note - 69) / 12);
	// Diatonic Scale
	float Frequency = 440.0 * FMath::Pow(2.0, (midiNote - 69) / 12.0);

	// Piano
//	float Frequency = 440.0 * pow(2.0, (midiNote - 49) / 12.0);
	return Frequency;
}

int32 UMyMidiUitls::FrequencyToMidiNote(float Frequency) {
	// midi note = log(Hertz/440.0)/log(2) * 12 + 69;
	int32 MidiNote = 69 + 12 * FMath::Log2(Frequency / 440.0);

//	int32 MidiNote = 49 + 12 * log2(Frequency / 440.0);
	return MidiNote;
}

int32 FrequencyToCent(float Frequency) {
	// cent = log(Hertz/440.0)/log(2) * 12;
	int32 Cent = FMath::Log2(Frequency / 440.0) * 1200.0;
	return Cent;
}

int32 FrequencyToOctave(float Frequency) {
	// octave = log(Hertz/440.0)/log(2);
	int32 Octave = FMath::Log2(Frequency / 440.0);
	return Octave;
}

FString UMyMidiUitls::ParseMidiPreview(const TArray<uint8>& data)
{
	FString test;
	MidiFile* file = new MidiFile((uint8*)data.GetData(), data.Num());

	for (int i = 0; i < file->getTracks().Num(); i++) {
		MidiTrack* track = file->getTracks()[i];

		test.Append(FString::FormatAsNumber(i));
		test.Append("\n");
		for (int it = 0; it < track->getEvents().Num(); it++) {
			MidiEvent* next = track->getEvents()[it];
			if (next->getType() == (ChannelEvent::NOTE_ON & 0X0F)) {
				NoteOn* note = (NoteOn*)next;
				FString text = FString("C C#D D#E F F#G G#A A#B ").Mid((note->getNoteValue() % 12) * 2, 2);
				test.Append(text);
				//test.Append("(" + FString::FormatAsNumber(next->getTick()) + ")");
			}
			if (next->getType() == (ChannelEvent::NOTE_OFF & 0X0F)) {
		//		NoteOff* note = (NoteOff*)next;
				//FString text = FString("C C#D D#E F F#G G#A A#B ").Mid((note->getNoteValue() % 12) * 2, 2);
				test.Append("---");
			}
		}
		test.Append("\n");
	}
	delete file;

	return test;
}